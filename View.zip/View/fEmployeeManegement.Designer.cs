﻿namespace bankManagement
{
    partial class fEmployeeManegement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewEmployee = new DataGridView();
            buttonSubmit = new Button();
            labelQuanLyNhanVien = new Label();
            labelMatKhau = new Label();
            labelTenTaiKhoan = new Label();
            txbTenNhanVien = new TextBox();
            labelTenNhanVien = new Label();
            buttonDelete = new Button();
            comboBoxChucVu = new ComboBox();
            labelChucVu = new Label();
            txbTenTaiKhoan = new TextBox();
            txbMatKhau = new TextBox();
            txbID = new TextBox();
            labelID = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEmployee).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewEmployee
            // 
            dataGridViewEmployee.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewEmployee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEmployee.Location = new Point(10, 275);
            dataGridViewEmployee.Name = "dataGridViewEmployee";
            dataGridViewEmployee.RowHeadersWidth = 51;
            dataGridViewEmployee.Size = new Size(1260, 389);
            dataGridViewEmployee.TabIndex = 8;
            dataGridViewEmployee.CellClick += dataGridViewEmployee_CellClick;
            // 
            // buttonSubmit
            // 
            buttonSubmit.BackColor = SystemColors.ControlDark;
            buttonSubmit.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonSubmit.ForeColor = Color.Black;
            buttonSubmit.Location = new Point(416, 676);
            buttonSubmit.Name = "buttonSubmit";
            buttonSubmit.Size = new Size(146, 48);
            buttonSubmit.TabIndex = 6;
            buttonSubmit.Text = "Submit";
            buttonSubmit.UseVisualStyleBackColor = false;
            buttonSubmit.Click += btnSubmit_Click;
            // 
            // labelQuanLyNhanVien
            // 
            labelQuanLyNhanVien.AutoSize = true;
            labelQuanLyNhanVien.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelQuanLyNhanVien.Location = new Point(474, 55);
            labelQuanLyNhanVien.Name = "labelQuanLyNhanVien";
            labelQuanLyNhanVien.Size = new Size(301, 33);
            labelQuanLyNhanVien.TabIndex = 31;
            labelQuanLyNhanVien.Text = "QUẢN LÝ NHÂN VIÊN";
            // 
            // labelMatKhau
            // 
            labelMatKhau.AutoSize = true;
            labelMatKhau.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelMatKhau.Location = new Point(683, 151);
            labelMatKhau.Name = "labelMatKhau";
            labelMatKhau.Size = new Size(104, 24);
            labelMatKhau.TabIndex = 30;
            labelMatKhau.Text = "Mật khẩu:";
            // 
            // labelTenTaiKhoan
            // 
            labelTenTaiKhoan.AutoSize = true;
            labelTenTaiKhoan.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTenTaiKhoan.Location = new Point(641, 114);
            labelTenTaiKhoan.Name = "labelTenTaiKhoan";
            labelTenTaiKhoan.Size = new Size(146, 24);
            labelTenTaiKhoan.TabIndex = 29;
            labelTenTaiKhoan.Text = "Tên tài khoản:";
            // 
            // txbTenNhanVien
            // 
            txbTenNhanVien.Location = new Point(275, 151);
            txbTenNhanVien.Name = "txbTenNhanVien";
            txbTenNhanVien.Size = new Size(353, 27);
            txbTenNhanVien.TabIndex = 1;
            // 
            // labelTenNhanVien
            // 
            labelTenNhanVien.AutoSize = true;
            labelTenNhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTenNhanVien.Location = new Point(119, 150);
            labelTenNhanVien.Name = "labelTenNhanVien";
            labelTenNhanVien.Size = new Size(151, 24);
            labelTenNhanVien.TabIndex = 28;
            labelTenNhanVien.Text = "Tên nhân viên:";
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ControlDark;
            buttonDelete.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(568, 676);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(146, 48);
            buttonDelete.TabIndex = 7;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // comboBoxChucVu
            // 
            comboBoxChucVu.FormattingEnabled = true;
            comboBoxChucVu.Items.AddRange(new object[] { "admin", "user" });
            comboBoxChucVu.Location = new Point(275, 188);
            comboBoxChucVu.Name = "comboBoxChucVu";
            comboBoxChucVu.Size = new Size(353, 28);
            comboBoxChucVu.TabIndex = 5;
            // 
            // labelChucVu
            // 
            labelChucVu.AutoSize = true;
            labelChucVu.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelChucVu.Location = new Point(171, 188);
            labelChucVu.Name = "labelChucVu";
            labelChucVu.Size = new Size(97, 24);
            labelChucVu.TabIndex = 33;
            labelChucVu.Text = "Chức vụ:";
            // 
            // txbTenTaiKhoan
            // 
            txbTenTaiKhoan.Location = new Point(793, 114);
            txbTenTaiKhoan.Name = "txbTenTaiKhoan";
            txbTenTaiKhoan.Size = new Size(353, 27);
            txbTenTaiKhoan.TabIndex = 3;
            // 
            // txbMatKhau
            // 
            txbMatKhau.Location = new Point(793, 151);
            txbMatKhau.Name = "txbMatKhau";
            txbMatKhau.Size = new Size(353, 27);
            txbMatKhau.TabIndex = 4;
            // 
            // txbID
            // 
            txbID.Location = new Point(276, 112);
            txbID.Name = "txbID";
            txbID.Size = new Size(353, 27);
            txbID.TabIndex = 0;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelID.Location = new Point(233, 116);
            labelID.Name = "labelID";
            labelID.Size = new Size(36, 24);
            labelID.TabIndex = 38;
            labelID.Text = "ID:";
            // 
            // fEmployeeManegement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1282, 753);
            Controls.Add(txbID);
            Controls.Add(labelID);
            Controls.Add(txbMatKhau);
            Controls.Add(comboBoxChucVu);
            Controls.Add(labelChucVu);
            Controls.Add(dataGridViewEmployee);
            Controls.Add(buttonSubmit);
            Controls.Add(labelQuanLyNhanVien);
            Controls.Add(labelMatKhau);
            Controls.Add(txbTenTaiKhoan);
            Controls.Add(labelTenTaiKhoan);
            Controls.Add(txbTenNhanVien);
            Controls.Add(labelTenNhanVien);
            Controls.Add(buttonDelete);
            Name = "fEmployeeManegement";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fEmployeeManegement";
            ((System.ComponentModel.ISupportInitialize)dataGridViewEmployee).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewEmployee;
        private Button buttonSubmit;
        private Label labelQuanLyNhanVien;
        private Label labelMatKhau;
        private Label labelTenTaiKhoan;
        private TextBox txbTenNhanVien;
        private Label labelTenNhanVien;
        private Button buttonDelete;
        private ComboBox comboBoxChucVu;
        private Label labelChucVu;
        private TextBox txbTenTaiKhoan;
        private TextBox txbMatKhau;
        private TextBox txbID;
        private Label labelID;
    }
}