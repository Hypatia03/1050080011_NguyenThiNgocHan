﻿namespace bankManagement
{
    partial class fAccountManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewAccount = new DataGridView();
            buttonSubmit = new Button();
            buttonDelete = new Button();
            dateTimeNgayGiaoDich = new DateTimePicker();
            txbSoTien = new TextBox();
            labelThongKe = new Label();
            labelNgayTao = new Label();
            labelQuanLyTaiKhoan = new Label();
            labelMaKhachHang = new Label();
            txbID = new TextBox();
            labelID = new Label();
            txbMaKhachHang = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAccount).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewAccount
            // 
            dataGridViewAccount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewAccount.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAccount.Location = new Point(12, 250);
            dataGridViewAccount.Name = "dataGridViewAccount";
            dataGridViewAccount.RowHeadersWidth = 51;
            dataGridViewAccount.Size = new Size(1258, 416);
            dataGridViewAccount.TabIndex = 0;
            dataGridViewAccount.CellClick += dataGridViewAccount_CellClick;
            // 
            // buttonSubmit
            // 
            buttonSubmit.BackColor = SystemColors.ControlDark;
            buttonSubmit.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonSubmit.ForeColor = Color.Black;
            buttonSubmit.Location = new Point(421, 672);
            buttonSubmit.Name = "buttonSubmit";
            buttonSubmit.Size = new Size(146, 48);
            buttonSubmit.TabIndex = 27;
            buttonSubmit.Text = "Submit";
            buttonSubmit.UseVisualStyleBackColor = false;
            buttonSubmit.Click += btnSubmit_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ControlDark;
            buttonDelete.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(573, 672);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(146, 48);
            buttonDelete.TabIndex = 28;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // dateTimeNgayGiaoDich
            // 
            dateTimeNgayGiaoDich.Location = new Point(738, 121);
            dateTimeNgayGiaoDich.Name = "dateTimeNgayGiaoDich";
            dateTimeNgayGiaoDich.Size = new Size(357, 27);
            dateTimeNgayGiaoDich.TabIndex = 45;
            // 
            // txbSoTien
            // 
            txbSoTien.Location = new Point(738, 158);
            txbSoTien.Name = "txbSoTien";
            txbSoTien.Size = new Size(357, 27);
            txbSoTien.TabIndex = 43;
            // 
            // labelThongKe
            // 
            labelThongKe.AutoSize = true;
            labelThongKe.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelThongKe.Location = new Point(644, 166);
            labelThongKe.Name = "labelThongKe";
            labelThongKe.Size = new Size(88, 19);
            labelThongKe.TabIndex = 44;
            labelThongKe.Text = "Thống kê:";
            // 
            // labelNgayTao
            // 
            labelNgayTao.AutoSize = true;
            labelNgayTao.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNgayTao.Location = new Point(644, 129);
            labelNgayTao.Name = "labelNgayTao";
            labelNgayTao.Size = new Size(85, 19);
            labelNgayTao.TabIndex = 42;
            labelNgayTao.Text = "Ngày tạo:";
            // 
            // labelQuanLyTaiKhoan
            // 
            labelQuanLyTaiKhoan.AutoSize = true;
            labelQuanLyTaiKhoan.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelQuanLyTaiKhoan.Location = new Point(518, 61);
            labelQuanLyTaiKhoan.Name = "labelQuanLyTaiKhoan";
            labelQuanLyTaiKhoan.Size = new Size(301, 33);
            labelQuanLyTaiKhoan.TabIndex = 41;
            labelQuanLyTaiKhoan.Text = "QUẢN LÝ TÀI KHOẢN";
            // 
            // labelMaKhachHang
            // 
            labelMaKhachHang.AutoSize = true;
            labelMaKhachHang.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelMaKhachHang.Location = new Point(109, 162);
            labelMaKhachHang.Name = "labelMaKhachHang";
            labelMaKhachHang.Size = new Size(133, 19);
            labelMaKhachHang.TabIndex = 40;
            labelMaKhachHang.Text = "Mã khách hàng:";
            // 
            // txbID
            // 
            txbID.Location = new Point(258, 121);
            txbID.Name = "txbID";
            txbID.Size = new Size(357, 27);
            txbID.TabIndex = 54;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelID.Location = new Point(218, 129);
            labelID.Name = "labelID";
            labelID.Size = new Size(31, 19);
            labelID.TabIndex = 55;
            labelID.Text = "ID:";
            // 
            // txbMaKhachHang
            // 
            txbMaKhachHang.Location = new Point(258, 158);
            txbMaKhachHang.Name = "txbMaKhachHang";
            txbMaKhachHang.Size = new Size(357, 27);
            txbMaKhachHang.TabIndex = 56;
            // 
            // fAccountManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1282, 753);
            Controls.Add(txbMaKhachHang);
            Controls.Add(txbID);
            Controls.Add(labelID);
            Controls.Add(dateTimeNgayGiaoDich);
            Controls.Add(txbSoTien);
            Controls.Add(labelThongKe);
            Controls.Add(labelNgayTao);
            Controls.Add(labelQuanLyTaiKhoan);
            Controls.Add(labelMaKhachHang);
            Controls.Add(buttonSubmit);
            Controls.Add(buttonDelete);
            Controls.Add(dataGridViewAccount);
            Name = "fAccountManagement";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fAccount";
            ((System.ComponentModel.ISupportInitialize)dataGridViewAccount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewAccount;
        private Button buttonAdd;
        private Button buttonSubmit;
        private Button buttonDelete;
        private DateTimePicker dateTimeNgayGiaoDich;
        private TextBox txbSoTien;
        private Label labelThongKe;
        private Label labelNgayTao;
        private Label labelQuanLyTaiKhoan;
        private Label labelMaKhachHang;
        private PictureBox pictureCustomer;
        private TextBox txbID;
        private Label labelID;
        private TextBox txbMaKhachHang;
    }
}