﻿using bankManagement.Controller;
using bankManagement.Model;
using bankManagement.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;
using Excel = Microsoft.Office.Interop.Excel;


namespace bankManagement
{
    public partial class fCustomerManagement : Form, IView
    {
        customerController customerCtrl;
        customerModel customerM;
        public fCustomerManagement()
        {
            InitializeComponent();
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            customerCtrl = new customerController();
            customerM = new customerModel();
            LoadDataToGridView();
        }
        public void SetDataToText()
        {
            txbID.Text = customerM.id;
            txbTenKhachHang.Text = customerM.name;
            txbSoDienThoai.Text = customerM.phone;
            txbEmail.Text = customerM.email;
            txbDiaChi.Text = customerM.house_no;
            comboBoxQueQuan.Text = customerM.city;
            txbMaXacNhan.Text = customerM.pin;
        }

        public void GetDataFromText()
        {
            string id = this.txbID.Text;
            string name = this.txbTenKhachHang.Text;
            string phone = this.txbSoDienThoai.Text;
            string email = this.txbEmail.Text;
            string house_no = this.txbDiaChi.Text;
            string city = this.comboBoxQueQuan.Text;
            string pin = this.txbMaXacNhan.Text;
            customerM.id = id;
            customerM.name = name;
            customerM.phone = phone;
            customerM.email = email;
            customerM.house_no = house_no;
            customerM.city = city;
            customerM.pin = pin;
        }
        public void LoadDataToGridView()
        {
            // Gọi hàm GetDataFromText để lấy dữ liệu từ các control
            GetDataFromText();

            // Sau khi đã có dữ liệu từ GetDataFromText, tiếp tục load dữ liệu
            customerCtrl.Load();
            dataGridViewCustomer.DataSource = customerCtrl.Items.OfType<customerModel>().ToList();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ các trường nhập liệu
            GetDataFromText();

            // Kiểm tra đối tượng đã tồn tại trong cơ sở dữ liệu hay chưa
            if (customerCtrl.IsExist(customerM))
            {
                // Nếu tồn tại, thì gọi hàm Update
                bool updated = customerCtrl.Update(customerM);
                if (updated)
                {
                    MessageBox.Show("Cập nhật chi nhánh thành công!");
                }
                else
                {
                    MessageBox.Show("Cập nhật chi nhánh thất bại!");
                }
            }
            else
            {
                // Nếu không tồn tại, thì gọi hàm Create
                bool created = customerCtrl.Create(customerM);
                if (created)
                {
                    MessageBox.Show("Thêm khách hàng mới thành công!");
                }
                else
                {
                    MessageBox.Show("Thêm khách hàng mới thất bại!");
                }
            }
            fCustomerManagement fCustomerManagement = new fCustomerManagement();
            this.Close();
            fCustomerManagement.ShowDialog();
        }
        private void dataGridViewCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Kiểm tra xem dòng được chọn có hợp lệ không
            if (e.RowIndex >= 0)
            {
                // Lấy dữ liệu từ dòng được chọn trong DataGridView
                DataGridViewRow row = dataGridViewCustomer.Rows[e.RowIndex];

                // Gán dữ liệu từ DataGridView vào biến toàn cục branchM
                customerM = new customerModel
                (
                    row.Cells["id"].Value.ToString(),   
                    row.Cells["name"].Value.ToString(), 
                    row.Cells["phone"].Value.ToString(),
                    row.Cells["email"].Value.ToString(),
                    row.Cells["house_no"].Value.ToString(), 
                    row.Cells["city"].Value.ToString(),  
                    row.Cells["pin"].Value.ToString()
                );

                // Hiển thị dữ liệu lên các ô nhập liệu (TextBox, ComboBox)
                SetDataToText();
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem ô ID có dữ liệu không
            if (!string.IsNullOrEmpty(txbID.Text))
            {
                // Tạo đối tượng customerModel với ID lấy từ TextBox
                customerModel customerM = new customerModel
                {
                    id = txbID.Text
                };

                // Gọi phương thức Delete để xóa bản ghi trong cơ sở dữ liệu
                bool isDeleted = customerCtrl.Delete(customerM);

                // Kiểm tra kết quả và thông báo cho người dùng
                if (isDeleted)
                {
                    MessageBox.Show("Đã xóa khách hàng thành công!");
                    // Cập nhật lại DataGridView (nạp lại dữ liệu)
                }
                else
                {
                    MessageBox.Show("Xóa khách hàng thất bại!");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn khách hàng cần xóa!");
            }
            fCustomerManagement fCustomerManagement = new fCustomerManagement();
            this.Close();
            fCustomerManagement.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            throw new NotImplementedException();
              }
         
    }
}
