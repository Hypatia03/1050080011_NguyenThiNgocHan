﻿using bankManagement.Controller;
using bankManagement.Model;
using bankManagement.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace bankManagement
{
    public partial class fAccountManagement : Form, IView
    {
        accountController accountCtrl;
        accountModel accountM;
        customerModel customerM;
        public fAccountManagement()
        {
            InitializeComponent();
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            accountCtrl = new accountController();
            accountM = new accountModel();
            customerM = new customerModel();

            LoadDataToGridView();
        }
        public void SetDataToText()
        {
            txbID.Text = accountM.id;
            txbMaKhachHang.Text = accountM.customerid.name;
            dateTimeNgayGiaoDich.Value = accountM.date_opened;
            txbSoTien.Text = accountM.balance.ToString();
        }

        public void GetDataFromText()
        {
            string id = this.txbID.Text;
            string customerName = this.txbMaKhachHang.Text;
            DateTime dateOpened = this.dateTimeNgayGiaoDich.Value;

            // Ép kiểu, xử lý các chuỗi rỗng
            string balanceString = this.txbSoTien.Text;
            float balance = string.IsNullOrWhiteSpace(balanceString) ? 0 : float.Parse(balanceString);

            accountM.id = id;
            accountM.date_opened = dateOpened;
            accountM.balance = balance;

            // initialized
            if (customerM == null)
            {
                customerM = new customerModel();
            }

            // Gán tên khách hàng
            customerM.name = customerName;

            // lấy toàn bộ dữ liệu của customer gán vào customerid của account (tức là accountM.customerid có thể lấy giá trị các cột của customer)
            accountM.customerid = customerM; // Ensure customerid is of type customerModel
        }
        public void LoadDataToGridView()
        {
            accountCtrl.Load();

            // Dùng LinQ để hiển thị dữ liệu từ các thuộc tính
            var accounts = accountCtrl.Items.OfType<accountModel>().Select(a => new
            {
                a.id,
                CustomerName = a.CustomerName,
                a.date_opened,
                a.balance
            }).ToList();

            // đưa dữ liệu vào dataGridView
            dataGridViewAccount.DataSource = accounts;
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ các trường nhập liệu
            GetDataFromText();

            // Kiểm tra đối tượng đã tồn tại trong cơ sở dữ liệu hay chưa
            if (accountCtrl.IsExist(accountM))
            {
                // Nếu tồn tại, thì gọi hàm Update
                bool updated = accountCtrl.Update(accountM);
                if (updated)
                {
                    MessageBox.Show("Cập nhật tài khoản thành công!");
                }
                else
                {
                    MessageBox.Show("Cập nhật chi nhánh thất bại!");
                }
            }
            else
            {
                // Nếu không tồn tại, thì gọi hàm Create
                bool created = accountCtrl.Create(accountM);
                if (created)
                {
                    MessageBox.Show("Thêm tài khoản mới thành công!");
                }
                else
                {
                    MessageBox.Show("Thêm tài khoản mới thất bại!");
                }
            }
            fAccountManagement fAccountManagement = new fAccountManagement();
            this.Close();
            fAccountManagement.ShowDialog();
        }
        private void dataGridViewAccount_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Đảm bảo rằng đã chọn một dòng hợp lệ
            {
                // Lấy dữ liệu từ dòng đã chọn
                var selectedRow = dataGridViewAccount.Rows[e.RowIndex];

                // Khởi tạo đối tượng nếu chưa được khởi tạo
                if (accountM.customerid == null)
                {
                    accountM.customerid = new customerModel(); 
                }

                // Gán giá trị cho các thuộc tính
                accountM.id = selectedRow.Cells["id"].Value.ToString();
                accountM.customerid.id = selectedRow.Cells["CustomerName"].Value.ToString(); 
                accountM.date_opened = Convert.ToDateTime(selectedRow.Cells["date_opened"].Value);
                accountM.balance = Convert.ToSingle(selectedRow.Cells["balance"].Value);

                // Cập nhật dữ liệu lên các ô nhập liệu
                SetDataToText();
            }
        }
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem ô ID có dữ liệu không
            if (!string.IsNullOrEmpty(txbID.Text))
            {
                
                accountModel accountM = new accountModel()
                {
                    id = txbID.Text
                };

                // Gọi phương thức Delete để xóa bản ghi trong cơ sở dữ liệu
                bool isDeleted = accountCtrl.Delete(accountM);

                // Kiểm tra kết quả và thông báo cho người dùng
                if (isDeleted)
                {
                    MessageBox.Show("Đã xóa tài khoản thành công!");
                    // Cập nhật lại DataGridView (nạp lại dữ liệu)
                }
                else
                {
                    MessageBox.Show("Xóa tài khoản thất bại!");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn tài khoản cần xóa!");
            }
            fAccountManagement fAccountManagement = new fAccountManagement();
            this.Close();
            fAccountManagement.ShowDialog();
        }
 
    }
}
