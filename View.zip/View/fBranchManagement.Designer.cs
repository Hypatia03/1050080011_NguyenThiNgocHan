﻿namespace bankManagement
{
    partial class fBranchManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewBranch = new DataGridView();
            buttonDelete = new Button();
            labelTenChiNhanh = new Label();
            txbTenChiNhanh = new TextBox();
            labelDiaChi = new Label();
            txbSoNha = new TextBox();
            labelThanhPho = new Label();
            labelQuanLyChiNhanh = new Label();
            comboBoxThanhPho = new ComboBox();
            buttonSubmit = new Button();
            txtID = new TextBox();
            labelID = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBranch).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewBranch
            // 
            dataGridViewBranch.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewBranch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBranch.Location = new Point(10, 239);
            dataGridViewBranch.Name = "dataGridViewBranch";
            dataGridViewBranch.RowHeadersWidth = 51;
            dataGridViewBranch.Size = new Size(1260, 425);
            dataGridViewBranch.TabIndex = 3;
            dataGridViewBranch.CellClick += dataGridViewBranch_CellClick;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ControlDark;
            buttonDelete.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(584, 670);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(146, 48);
            buttonDelete.TabIndex = 5;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // labelTenChiNhanh
            // 
            labelTenChiNhanh.AutoSize = true;
            labelTenChiNhanh.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTenChiNhanh.Location = new Point(15, 177);
            labelTenChiNhanh.Name = "labelTenChiNhanh";
            labelTenChiNhanh.Size = new Size(152, 24);
            labelTenChiNhanh.TabIndex = 12;
            labelTenChiNhanh.Text = "Tên chi nhánh:";
            // 
            // txbTenChiNhanh
            // 
            txbTenChiNhanh.Location = new Point(172, 174);
            txbTenChiNhanh.Name = "txbTenChiNhanh";
            txbTenChiNhanh.Size = new Size(429, 27);
            txbTenChiNhanh.TabIndex = 1;
            // 
            // labelDiaChi
            // 
            labelDiaChi.AutoSize = true;
            labelDiaChi.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelDiaChi.Location = new Point(697, 140);
            labelDiaChi.Name = "labelDiaChi";
            labelDiaChi.Size = new Size(81, 24);
            labelDiaChi.TabIndex = 14;
            labelDiaChi.Text = "Địa chỉ:";
            // 
            // txbSoNha
            // 
            txbSoNha.Location = new Point(786, 140);
            txbSoNha.Name = "txbSoNha";
            txbSoNha.Size = new Size(429, 27);
            txbSoNha.TabIndex = 2;
            // 
            // labelThanhPho
            // 
            labelThanhPho.AutoSize = true;
            labelThanhPho.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelThanhPho.Location = new Point(662, 178);
            labelThanhPho.Name = "labelThanhPho";
            labelThanhPho.Size = new Size(119, 24);
            labelThanhPho.TabIndex = 16;
            labelThanhPho.Text = "Thành phố:";
            // 
            // labelQuanLyChiNhanh
            // 
            labelQuanLyChiNhanh.AutoSize = true;
            labelQuanLyChiNhanh.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelQuanLyChiNhanh.Location = new Point(507, 62);
            labelQuanLyChiNhanh.Name = "labelQuanLyChiNhanh";
            labelQuanLyChiNhanh.Size = new Size(303, 33);
            labelQuanLyChiNhanh.TabIndex = 18;
            labelQuanLyChiNhanh.Text = "QUẢN LÝ CHI NHÁNH";
            // 
            // comboBoxThanhPho
            // 
            comboBoxThanhPho.FormattingEnabled = true;
            comboBoxThanhPho.Items.AddRange(new object[] { "An Giang", "Bà Rịa - Vũng Tàu", "Bạc Liêu", "Bắc Giang", "Bắc Kạn", "Bắc Ninh", "Bến Tre", "Bình Dương", "Bình Định", "Bình Phước", "Bình Thuận", "Cà Mau", "Cần Thơ", "Cao Bằng", "Đà Nẵng", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Giang", "Hà Nam", "Hà Nội", "Hải Dương", "Hải Phòng", "Hậu Giang", "Hòa Bình", "Hưng Yên", "Khánh Hòa", "Kiên Giang", "Kon Tum", "Lai Châu", "Lạng Sơn", "Lào Cai", "Long An", "Nam Định", "Nghệ An", "Ninh Bình", "Ninh Thuận", "Phú Thọ", "Quảng Bình", "Quảng Nam", "Quảng Ngãi", "Quảng Ninh", "Quảng Trị", "Sóc Trăng", "Sơn La", "Tây Ninh", "Thái Bình", "Thái Nguyên", "Thanh Hóa", "Tiền Giang", "Trà Vinh", "Tuyên Quang", "Vĩnh Long", "Vĩnh Phúc", "Yên Bái " });
            comboBoxThanhPho.Location = new Point(786, 174);
            comboBoxThanhPho.Name = "comboBoxThanhPho";
            comboBoxThanhPho.Size = new Size(429, 28);
            comboBoxThanhPho.TabIndex = 3;
            // 
            // buttonSubmit
            // 
            buttonSubmit.BackColor = SystemColors.ControlDark;
            buttonSubmit.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonSubmit.ForeColor = Color.Black;
            buttonSubmit.Location = new Point(432, 670);
            buttonSubmit.Name = "buttonSubmit";
            buttonSubmit.Size = new Size(146, 48);
            buttonSubmit.TabIndex = 4;
            buttonSubmit.Text = "Submit";
            buttonSubmit.UseVisualStyleBackColor = false;
            buttonSubmit.Click += btnSubmit_Click;
            // 
            // txtID
            // 
            txtID.Location = new Point(172, 137);
            txtID.Name = "txtID";
            txtID.Size = new Size(429, 27);
            txtID.TabIndex = 0;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelID.Location = new Point(130, 140);
            labelID.Name = "labelID";
            labelID.Size = new Size(36, 24);
            labelID.TabIndex = 23;
            labelID.Text = "ID:";
            // 
            // fBranchManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1282, 753);
            Controls.Add(txtID);
            Controls.Add(labelID);
            Controls.Add(buttonSubmit);
            Controls.Add(comboBoxThanhPho);
            Controls.Add(labelQuanLyChiNhanh);
            Controls.Add(labelThanhPho);
            Controls.Add(txbSoNha);
            Controls.Add(labelDiaChi);
            Controls.Add(txbTenChiNhanh);
            Controls.Add(labelTenChiNhanh);
            Controls.Add(buttonDelete);
            Controls.Add(dataGridViewBranch);
            Name = "fBranchManagement";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fBranchManagement";
            ((System.ComponentModel.ISupportInitialize)dataGridViewBranch).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dataGridViewBranch;
        private Button buttonDelete;
        private Label labelTenChiNhanh;
        private TextBox txbTenChiNhanh;
        private Label labelDiaChi;
        private TextBox txbSoNha;
        private Label labelThanhPho;
        private Label labelQuanLyChiNhanh;
        private ComboBox comboBoxThanhPho;
        private Button buttonUpdate;
        private Button buttonSubmit;
        private TextBox txtID;
        private Label labelID;
    }
}