﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankManagement
{
    public partial class fMainManager : Form
    {
        public fMainManager()
        {
            InitializeComponent();
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            this.WindowState = FormWindowState.Maximized;
            //loadMain();
        }
        private void clickToPageLogin(object sender, EventArgs e)
        {
            fLogin loginForm = new fLogin(this);
            loginForm.ShowDialog();  // Hiển thị form đăng nhập
        }

        private void clickToPageBranchManagement(object sender, EventArgs e)
        {
            fBranchManagement fBranch = new fBranchManagement();
            fBranch.ShowDialog();
            this.Show();
        }

        private void clickToPageTracsactionManagement(object sender, EventArgs e)
        {
            //fTransactionManagement fTransaction = new fTransactionManagement();
            //fTransaction.ShowDialog();
            //this.Show();
        }

        private void clickToPageEmployeeManagement(object sender, EventArgs e)
        {
         fEmployeeManegement fEmployeeManegement = new fEmployeeManegement();   
            fEmployeeManegement.ShowDialog();
            this.Show();
        }

        private void clickToPageCustomerManagement(object sender, EventArgs e)
        {
            fCustomerManagement fCustomer = new fCustomerManagement();
            fCustomer.ShowDialog();
            this.Show();
        }

        private void clickToPageAccountManagement(object sender, EventArgs e)
        {
            fAccountManagement fAccount = new fAccountManagement();
            fAccount.ShowDialog();
            this.Show();
        }
        private void ShowBranchManagement()
        {
            fBranchManagement fBranch = new fBranchManagement();   
            fBranch.ShowDialog();
            this.Show();
        }
        private void ShowEmployeeManagement()
        {
            fEmployeeManegement fEmployee = new fEmployeeManegement();
            fEmployee.ShowDialog();
            this.Show();
        }

    }
}
