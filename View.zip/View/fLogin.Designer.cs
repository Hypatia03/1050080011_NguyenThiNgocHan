﻿namespace bankManagement
{
    partial class fLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            dangNhapTittle = new Label();
            txbMatKhau = new TextBox();
            txbTenDangNhap = new TextBox();
            matKhauTittle = new Label();
            thoatButton = new Button();
            tenDangNhapTittle = new Label();
            dangNhapButton = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(dangNhapTittle);
            panel1.Controls.Add(txbMatKhau);
            panel1.Controls.Add(txbTenDangNhap);
            panel1.Controls.Add(matKhauTittle);
            panel1.Controls.Add(thoatButton);
            panel1.Controls.Add(tenDangNhapTittle);
            panel1.Controls.Add(dangNhapButton);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(666, 315);
            panel1.TabIndex = 0;
            // 
            // dangNhapTittle
            // 
            dangNhapTittle.AutoSize = true;
            dangNhapTittle.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dangNhapTittle.Location = new Point(249, 55);
            dangNhapTittle.Name = "dangNhapTittle";
            dangNhapTittle.Size = new Size(169, 35);
            dangNhapTittle.TabIndex = 0;
            dangNhapTittle.Text = "Đăng nhập";
            // 
            // txbMatKhau
            // 
            txbMatKhau.Location = new Point(249, 159);
            txbMatKhau.Name = "txbMatKhau";
            txbMatKhau.Size = new Size(365, 27);
            txbMatKhau.TabIndex = 2;
            txbMatKhau.UseSystemPasswordChar = true;
            // 
            // txbTenDangNhap
            // 
            txbTenDangNhap.Location = new Point(249, 127);
            txbTenDangNhap.Name = "txbTenDangNhap";
            txbTenDangNhap.Size = new Size(365, 27);
            txbTenDangNhap.TabIndex = 1;
            // 
            // matKhauTittle
            // 
            matKhauTittle.AutoSize = true;
            matKhauTittle.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            matKhauTittle.Location = new Point(112, 156);
            matKhauTittle.Name = "matKhauTittle";
            matKhauTittle.Size = new Size(110, 24);
            matKhauTittle.TabIndex = 0;
            matKhauTittle.Text = "Mật khẩu: ";
            // 
            // thoatButton
            // 
            thoatButton.BackColor = SystemColors.ButtonFace;
            thoatButton.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            thoatButton.Location = new Point(436, 191);
            thoatButton.Name = "thoatButton";
            thoatButton.Size = new Size(144, 38);
            thoatButton.TabIndex = 4;
            thoatButton.Text = "Thoát";
            thoatButton.UseVisualStyleBackColor = false;
            thoatButton.Click += thoatButton_Click;
            // 
            // tenDangNhapTittle
            // 
            tenDangNhapTittle.AutoSize = true;
            tenDangNhapTittle.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tenDangNhapTittle.Location = new Point(57, 127);
            tenDangNhapTittle.Name = "tenDangNhapTittle";
            tenDangNhapTittle.Size = new Size(159, 24);
            tenDangNhapTittle.TabIndex = 0;
            tenDangNhapTittle.Text = "Tên đăng nhập:";
            // 
            // dangNhapButton
            // 
            dangNhapButton.BackColor = SystemColors.ActiveCaption;
            dangNhapButton.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dangNhapButton.Location = new Point(267, 191);
            dangNhapButton.Name = "dangNhapButton";
            dangNhapButton.Size = new Size(144, 38);
            dangNhapButton.TabIndex = 3;
            dangNhapButton.Text = "Đăng nhập";
            dangNhapButton.UseVisualStyleBackColor = false;
            dangNhapButton.Click += dangNhapButton_Click;
            // 
            // fLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(690, 339);
            Controls.Add(panel1);
            Name = "fLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ĐĂNG NHẬP";
            FormClosing += fLogin_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label dangNhapTittle;
        private Button thoatButton;
        private Button dangNhapButton;
        private TextBox txbMatKhau;
        private Label matKhauTittle;
        private TextBox txbTenDangNhap;
        private Label tenDangNhapTittle;
    }
}
