﻿namespace bankManagement
{
    partial class fCustomerManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txbMaXacNhan = new TextBox();
            labelNhanVienPhuTrach = new Label();
            labelNguoiNhanTien = new Label();
            txbDiaChi = new TextBox();
            labelDiaChi = new Label();
            labelNgayGiaoDich = new Label();
            txbEmail = new TextBox();
            labelNganHang = new Label();
            dataGridViewCustomer = new DataGridView();
            labelQuanLyKhachHang = new Label();
            labelNguoiChuyenTien = new Label();
            txbTenKhachHang = new TextBox();
            txbSoDienThoai = new TextBox();
            comboBoxQueQuan = new ComboBox();
            buttonAdd = new Button();
            buttonDelete = new Button();
            labelID = new Label();
            txbID = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomer).BeginInit();
            SuspendLayout();
            // 
            // txbMaXacNhan
            // 
            txbMaXacNhan.Location = new Point(732, 191);
            txbMaXacNhan.Name = "txbMaXacNhan";
            txbMaXacNhan.Size = new Size(353, 27);
            txbMaXacNhan.TabIndex = 7;
            // 
            // labelNhanVienPhuTrach
            // 
            labelNhanVienPhuTrach.AutoSize = true;
            labelNhanVienPhuTrach.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNhanVienPhuTrach.Location = new Point(613, 199);
            labelNhanVienPhuTrach.Name = "labelNhanVienPhuTrach";
            labelNhanVienPhuTrach.Size = new Size(113, 19);
            labelNhanVienPhuTrach.TabIndex = 61;
            labelNhanVienPhuTrach.Text = "Mã xác nhận:";
            // 
            // labelNguoiNhanTien
            // 
            labelNguoiNhanTien.AutoSize = true;
            labelNguoiNhanTien.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNguoiNhanTien.Location = new Point(635, 162);
            labelNguoiNhanTien.Name = "labelNguoiNhanTien";
            labelNguoiNhanTien.Size = new Size(91, 19);
            labelNguoiNhanTien.TabIndex = 59;
            labelNguoiNhanTien.Text = "Quê quán:";
            // 
            // txbDiaChi
            // 
            txbDiaChi.Location = new Point(732, 113);
            txbDiaChi.Name = "txbDiaChi";
            txbDiaChi.Size = new Size(353, 27);
            txbDiaChi.TabIndex = 5;
            // 
            // labelDiaChi
            // 
            labelDiaChi.AutoSize = true;
            labelDiaChi.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelDiaChi.Location = new Point(656, 121);
            labelDiaChi.Name = "labelDiaChi";
            labelDiaChi.Size = new Size(68, 19);
            labelDiaChi.TabIndex = 56;
            labelDiaChi.Text = "Địa chỉ:";
            // 
            // labelNgayGiaoDich
            // 
            labelNgayGiaoDich.AutoSize = true;
            labelNgayGiaoDich.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNgayGiaoDich.Location = new Point(114, 199);
            labelNgayGiaoDich.Name = "labelNgayGiaoDich";
            labelNgayGiaoDich.Size = new Size(118, 19);
            labelNgayGiaoDich.TabIndex = 54;
            labelNgayGiaoDich.Text = "Số điện thoại:";
            // 
            // txbEmail
            // 
            txbEmail.Location = new Point(238, 228);
            txbEmail.Name = "txbEmail";
            txbEmail.Size = new Size(353, 27);
            txbEmail.TabIndex = 4;
            // 
            // labelNganHang
            // 
            labelNganHang.AutoSize = true;
            labelNganHang.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNganHang.Location = new Point(175, 236);
            labelNganHang.Name = "labelNganHang";
            labelNganHang.Size = new Size(57, 19);
            labelNganHang.TabIndex = 53;
            labelNganHang.Text = "Email:";
            // 
            // dataGridViewCustomer
            // 
            dataGridViewCustomer.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomer.Location = new Point(12, 289);
            dataGridViewCustomer.Name = "dataGridViewCustomer";
            dataGridViewCustomer.RowHeadersWidth = 51;
            dataGridViewCustomer.Size = new Size(1260, 376);
            dataGridViewCustomer.TabIndex = 48;
            dataGridViewCustomer.CellClick += dataGridViewCustomer_CellClick;
            // 
            // labelQuanLyKhachHang
            // 
            labelQuanLyKhachHang.AutoSize = true;
            labelQuanLyKhachHang.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelQuanLyKhachHang.Location = new Point(456, 55);
            labelQuanLyKhachHang.Name = "labelQuanLyKhachHang";
            labelQuanLyKhachHang.Size = new Size(337, 33);
            labelQuanLyKhachHang.TabIndex = 51;
            labelQuanLyKhachHang.Text = "QUẢN LÝ KHÁCH HÀNG";
            // 
            // labelNguoiChuyenTien
            // 
            labelNguoiChuyenTien.AutoSize = true;
            labelNguoiChuyenTien.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelNguoiChuyenTien.Location = new Point(92, 158);
            labelNguoiChuyenTien.Name = "labelNguoiChuyenTien";
            labelNguoiChuyenTien.Size = new Size(140, 19);
            labelNguoiChuyenTien.TabIndex = 50;
            labelNguoiChuyenTien.Text = "Tên khách hàng:";
            // 
            // txbTenKhachHang
            // 
            txbTenKhachHang.Location = new Point(238, 154);
            txbTenKhachHang.Name = "txbTenKhachHang";
            txbTenKhachHang.Size = new Size(353, 27);
            txbTenKhachHang.TabIndex = 2;
            // 
            // txbSoDienThoai
            // 
            txbSoDienThoai.Location = new Point(238, 191);
            txbSoDienThoai.Name = "txbSoDienThoai";
            txbSoDienThoai.Size = new Size(353, 27);
            txbSoDienThoai.TabIndex = 3;
            // 
            // comboBoxQueQuan
            // 
            comboBoxQueQuan.FormattingEnabled = true;
            comboBoxQueQuan.Items.AddRange(new object[] { "An Giang", "Bà Rịa - Vũng Tàu", "Bạc Liêu", "Bắc Giang", "Bắc Kạn", "Bắc Ninh", "Bến Tre", "Bình Dương", "Bình Định", "Bình Phước", "Bình Thuận", "Cà Mau", "Cần Thơ", "Cao Bằng", "Đà Nẵng", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Giang", "Hà Nam", "Hà Nội", "Hải Dương", "Hải Phòng", "Hậu Giang", "Hòa Bình", "Hưng Yên", "Khánh Hòa", "Kiên Giang", "Kon Tum", "Lai Châu", "Lạng Sơn", "Lào Cai", "Long An", "Nam Định", "Nghệ An", "Ninh Bình", "Ninh Thuận", "Phú Thọ", "Quảng Bình", "Quảng Nam", "Quảng Ngãi", "Quảng Ninh", "Quảng Trị", "Sóc Trăng", "Sơn La", "Tây Ninh", "Thái Bình", "Thái Nguyên", "Thanh Hóa", "Tiền Giang", "Trà Vinh", "Tuyên Quang", "Vĩnh Long", "Vĩnh Phúc", "Yên Bái " });
            comboBoxQueQuan.Location = new Point(732, 154);
            comboBoxQueQuan.Name = "comboBoxQueQuan";
            comboBoxQueQuan.Size = new Size(353, 28);
            comboBoxQueQuan.TabIndex = 6;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = SystemColors.ControlDark;
            buttonAdd.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonAdd.ForeColor = Color.Black;
            buttonAdd.Location = new Point(428, 671);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(146, 48);
            buttonAdd.TabIndex = 8;
            buttonAdd.Text = "Submit";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += btnSubmit_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ControlDark;
            buttonDelete.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(580, 671);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(146, 48);
            buttonDelete.TabIndex = 9;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += btnDelete_Click;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelID.Location = new Point(92, 121);
            labelID.Name = "labelID";
            labelID.Size = new Size(127, 19);
            labelID.TabIndex = 68;
            labelID.Text = "ID khách hàng:";
            // 
            // txbID
            // 
            txbID.Location = new Point(238, 117);
            txbID.Name = "txbID";
            txbID.Size = new Size(353, 27);
            txbID.TabIndex = 1;
            // 
            // fCustomerManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1282, 753);
            Controls.Add(labelID);
            Controls.Add(txbID);
            Controls.Add(comboBoxQueQuan);
            Controls.Add(txbSoDienThoai);
            Controls.Add(txbMaXacNhan);
            Controls.Add(labelNhanVienPhuTrach);
            Controls.Add(labelNguoiNhanTien);
            Controls.Add(txbDiaChi);
            Controls.Add(labelDiaChi);
            Controls.Add(labelNgayGiaoDich);
            Controls.Add(txbEmail);
            Controls.Add(labelNganHang);
            Controls.Add(dataGridViewCustomer);
            Controls.Add(buttonAdd);
            Controls.Add(labelQuanLyKhachHang);
            Controls.Add(labelNguoiChuyenTien);
            Controls.Add(buttonDelete);
            Controls.Add(txbTenKhachHang);
            Name = "fCustomerManagement";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fCustomerManagement";
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomer).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txbMaXacNhan;
        private Label labelNhanVienPhuTrach;
        private Label labelNguoiNhanTien;
        private DateTimePicker dateTimeNgayGiaoDich;
        private TextBox txbDiaChi;
        private Label labelDiaChi;
        private Label labelNgayGiaoDich;
        private TextBox txbEmail;
        private Label labelNganHang;
        private DataGridView dataGridViewCustomer;
        private Label labelQuanLyKhachHang;
        private Label labelNguoiChuyenTien;
        private TextBox txbTenKhachHang;
        private TextBox txbSoDienThoai;
        private ComboBox comboBoxQueQuan;
        private Button buttonAdd;
        private Button buttonDelete;
        private Label labelID;
        private TextBox txbID;
    }
}