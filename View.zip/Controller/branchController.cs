﻿using bankManagement.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Controller
{
    internal class branchController : IController
    {
        SqlConnection conn = connectDBS.getConnection();

        private List<IModel> _items;

        public List<IModel> Items => this._items;

        public branchController()
        {
            _items = new List<IModel>();
        }

        public bool Load()
        {
            try
            {
                conn.Open();
                string query = "SELECT * FROM Branch";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    branchModel branchM = new branchModel(
                        reader["id"].ToString(),
                        reader["name"].ToString(),
                        reader["house_no"].ToString(),
                        reader["city"].ToString()
                    );
                    _items.Add(branchM);
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();

            }
        }
        public bool IsExist(object model)
        {
            branchModel branch = (branchModel)model;

            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Branch WHERE id = '" + branch.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool Create(IModel model)
        {
            branchModel branch = (branchModel)model;

            try
            {
                conn.Open();
                string query = "INSERT INTO Branch (id, name, house_no, city) VALUES ('" +
                               branch.id + "', '" +
                               branch.name + "', '" +
                               branch.house_no + "', '" +
                               branch.city + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Update(IModel model)
        {
            branchModel branch = (branchModel)model;
            try
            {
                conn.Open();
                string query = "UPDATE Branch SET name = '" + branch.name +
                               "', house_no = '" + branch.house_no +
                               "', city = '" + branch.city +
                               "' WHERE id = '" + branch.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool Delete(IModel model)
        {
            branchModel branch = (branchModel)model;

            try
            {
                conn.Open();
                string query = "DELETE FROM Branch WHERE id = '" + branch.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Load(object id)
        {
            throw new NotImplementedException();
        }

        public IModel Read(object id)
        {
            throw new NotImplementedException();
        }
    }
}
