﻿using bankManagement.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Controller
{
    internal class accountController : IController
    {
        SqlConnection conn = connectDBS.getConnection();

        private List<IModel> _items;

        public List<IModel> Items => this._items;

        public accountController()
        {
            _items = new List<IModel>();
        }

        public bool Load()
        {
            try
            {
                conn.Open();
                // Truy vấn JOIN giữa bảng Account và Customer để lấy thông tin của cả account và customer
                string query = @"
            SELECT 
                Account.id AS accountID, 
                Account.date_opened, 
                Account.balance, 
                Customer.id AS customerID, 
                Customer.name AS customerName
            FROM 
                Account
            JOIN 
                Customer ON Account.customerid = Customer.id";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    // Tạo đối tượng customerModel từ dữ liệu lấy được
                    customerModel customer = new customerModel
                    {
                        id = reader["customerID"].ToString(),
                        name = reader["customerName"].ToString()
                    };

                    // Tạo đối tượng accountModel từ dữ liệu lấy được
                    accountModel account = new accountModel
                    (
                        reader["accountID"].ToString(),
                        customer,                      
                        Convert.ToDateTime(reader["date_opened"]),  
                        float.Parse(reader["balance"].ToString())   
                    );

                    // Thêm account vào danh sách hoặc tập hợp đối tượng (_items)
                    _items.Add(account);
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool IsExist(object model)
        {
            accountModel accountM = (accountModel)model;

            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Account WHERE id = '" + accountM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool Create(IModel model)
        {
            accountModel accountM = (accountModel)model;
            try
            {
                conn.Open();

                // Định dạng date_opened thành chuỗi theo định dạng YYYY-MM-DD HH:MM:SS
                string dateOpenedFormatted = accountM.date_opened.ToString("yyyy-MM-dd HH:mm:ss");

                string query = "INSERT INTO Account (id, customerid, date_opened, balance) VALUES ('" +
                               accountM.id + "', '" +
                               accountM.customerid.name + "', '" +
                               dateOpenedFormatted + "', '" +
                               accountM.balance + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Update(IModel model)
        {
            accountModel accountM = (accountModel)model;
            try
            {
                conn.Open();

                // Định dạng date_opened thành chuỗi theo định dạng YYYY-MM-DD HH:MM:SS
                string dateOpenedFormatted = accountM.date_opened.ToString("yyyy-MM-dd HH:mm:ss");

                string query = "UPDATE Account SET customerid = '" + accountM.CustomerName +
                               "', date_opened = '" + dateOpenedFormatted +
                               "', balance = '" + accountM.balance +
                               "' WHERE id = '" + accountM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }


        public bool Delete(IModel model)
        {
            accountModel accountM = (accountModel)model;

            try
            {
                conn.Open();
                string query = "DELETE FROM Account WHERE id = '" + accountM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Load(object id)
        {
            throw new NotImplementedException();
        }

        public IModel Read(object id)
        {
            throw new NotImplementedException();
        }

        public bool Login(string userName, string password)
        {
            string query = "SELECT COUNT(*) FROM Employee WHERE userName = @userName AND password = @password";

            // Sử dụng try-catch để bắt lỗi khi truy vấn database
            try
            {
                    conn.Open();

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        // Sử dụng parameterized query để tránh SQL Injection
                        command.Parameters.AddWithValue("@userName", userName);
                        command.Parameters.AddWithValue("@password", password);

                        // Thực thi câu lệnh và lấy kết quả
                        int result = (int)command.ExecuteScalar();

                        // Nếu kết quả trả về 1 (tài khoản tồn tại), đăng nhập thành công
                        return result == 1;
                    }
            }
            catch (Exception ex)
            {
                // Ghi log hoặc xử lý lỗi
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }
    }
}
