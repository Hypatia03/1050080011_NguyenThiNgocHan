﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Model
{
    internal class branchModel : IModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string house_no { get; set; }
        public string city { get; set; }
        public bool IsValidate()
        {
            return true;
        }

        public branchModel(){}
        public branchModel(string id, string name, string house_no, string city)
        {
            this.id = id;
            this.name = name;
            this.house_no = house_no;
            this.city = city;
        }
    }
}
