﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Model
{
    internal class accountModel : IModel
    {
        public string id { get; set; }
        public customerModel customerid { get; set; }
        public DateTime date_opened { get; set; }
        public float balance { get; set; }

        // Tạo thêm thuộc tính, để lấy giá trị từ customer
        public string CustomerName => customerid?.name;
        public bool IsValidate()
        {
            return true;
        }
        public accountModel() { }
        public accountModel(string id, customerModel customerid, DateTime date_opened, float balance)
        {
            this.id = id;
            this.customerid = customerid; 
            this.date_opened = date_opened;
            this.balance = balance;
        }
    }
}
